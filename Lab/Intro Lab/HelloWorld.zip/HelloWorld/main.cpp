

/* 
 * File:   main.cpp
 * Author: Elias Silva
 * Purpose: Hello World
 *
 * 
 */

//System Libraries 
#include <iostream>
using namespace std;

//Global Constants

//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here

int main(int argc, char** argv) 
{
    //Initialize range Random Number Seed
    
    //Declare Variables
   
    //Initialize Variables
    
    //Map inputs to outputs -> The process

    //Display Results
   
    cout << "Hello World" << endl;
    
    //Exit stage right
    return 0;
}
